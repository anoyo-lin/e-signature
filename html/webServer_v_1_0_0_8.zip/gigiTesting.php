<?php
$jpegImage = imagecreatefromjpeg("/var/www/html/testing2/uploads/sign.jpg");
imagebmp($jpegImage, "/var/www/html/testing2/testing.bmp");
//imagebmp($jpegImage);

function imagebmp(&$image, $filename = false)
{
	if(!$image)
		return false;
	
	if(!$filename)
		return false;
	
	$width = imagesx($image);
    $height = imagesy($image);
    $width_pad = str_pad('', (4-ceil($width/8) % 4) %4, "\0");

    $size = 62 + ( ceil($width/8) + strlen($width_pad)) * $height;

    //prepare & save header
    $header['identifier']       = 'BM';
    $header['file_size']        = pack("V", $size);
    $header['reserved']         = pack("V", 0);
    $header['bitmap_data']      = pack("V", 62);
    $header['header_size']      = pack("V", 40);
    $header['width']            = pack("V", $width);
    $header['height']           = pack("V", $height);
    $header['planes']           = pack("v", 1);
    $header['bits_per_pixel']   = pack("v", 1);
    $header['compression']      = pack("V", 0);
    $header['data_size']        = pack("V", 0);
    $header['h_resolution']     = pack("V", 0);
    $header['v_resolution']     = pack("V", 0);
    $header['colors']           = pack("V", 0);
    $header['important_colors'] = pack("V", 0);
    $header['white']    = chr(255).chr(255).chr(255).chr(0);
    $header['black']    = chr(0).chr(0).chr(0).chr(0);
	
	$f = fopen($filename, "wb");
	foreach ($header AS $headerContent)
		fwrite($f, $headerContent);

	//save pixels
	$str = "";
	for ($y=$height-1; $y>=0; $y--) {
		$str = "";
		for ($x=0; $x<$width; $x++) {
			$rgb = imagecolorat($image, $x, $y);
			$red = ($rgb >> 16) & 0xFF;
			$green = ($rgb >> 8) & 0xFF;
			$blue = $rgb & 0xFF;
			$gs = (($red*0.299) + ($green*0.587) + ($blue*0.114));
			if($gs>150) 
				$color=0;
			else 
				$color=1;
			$str = $str.$color;
			if($x == $width-1)
				$str=str_pad($str, 8, "0");
			if(strlen($str) == 8){
				fwrite($f, chr((int)bindec($str)));
				$str="";
			}
		}
		fwrite($f, $width_pad);
	}
	fclose($f);
	
    /*if ($filename)
    {
        $f = fopen($filename, "wb");
        foreach ($header AS $h)
        {
            fwrite($f, $h);
        }

        //save pixels
        $str="";
        for ($y=$height-1; $y>=0; $y--)
        {
            $str="";
            for ($x=0; $x<$width; $x++)
            {
                $rgb = imagecolorat($image, $x, $y);
                $r = ($rgb >> 16) & 0xFF;
                $g = ($rgb >> 8) & 0xFF;
                $b = $rgb & 0xFF;
                $gs = (($r*0.299)+($g*0.587)+($b*0.114));
                if($gs>150) $color=0;
                else $color=1;
                $str=$str.$color;
                if($x==$width-1){
                    $str=str_pad($str, 8, "0");
                }               
                if(strlen($str)==8){
                    fwrite($f, chr((int)bindec($str)));
                    $str="";
                }
            }
            fwrite($f, $width_pad);
        }
        fclose($f);

    }
    else
    {
        foreach ($header AS $h)
        {
            echo $h;
        }

        //save pixels
        for ($y=$height-1; $y>=0; $y--)
        {
            for ($x=0; $x<$width; $x++)
            {
                $rgb = imagecolorat($image, $x, $y);
                $r = ($rgb >> 16) & 0xFF;
                $g = ($rgb >> 8) & 0xFF;
                $b = $rgb & 0xFF;
                $gs = (($r*0.299)+($g*0.587)+($b*0.114));
                if($gs>150) $color=0;
                else $color=1;
                $str=$str.$color;
                if($x==$width-1){
                    $str=str_pad($str, 8, "0");
                }
                if(strlen($str)==8){
                    echo chr((int)bindec($str));
                    $str="";
                }
            }
            echo $width_pad;
        }
    }*/
}


function dword($n)
{
    return pack("V", $n);
}
function word($n)
{
    return pack("v", $n);
}
?>
