<?php
	header('Content-Type: text/html; charset=Big5');
	
	/***********************************************/
	/*****			Main Program			   *****/
	/***********************************************/
	if ($argv[1] == "genImageInBase64") {
		$inputFileName = $argv[2];
		$outputFileName = $argv[3];
		$codepage = $argv[4];
		//$chkImgWidth = $argv[5];
		$chkImgType = $argv[5];
		$billImageFile = "bill_".date("His").".jpg";
		//txtFileToJpegImage($inputFileName, $billImageFile, $codepage, $chkImgWidth);
		txtFileToJpegImage($inputFileName, $billImageFile, $codepage, $chkImgType, "000000");
		convertJpegImageToBase64($billImageFile, $outputFileName);
		unlink($billImageFile);
		
	}else if ($argv[1] == "genJpegImage") {
		$inputFileName = $argv[2];
		$outputFileName = $argv[3];
		$codepage = $argv[4];
		$checkNo = $argv[5];
		$checkWidth = $argv[6];
		txtFileToJpegImage($inputFileName, $outputFileName, $codepage, $checkWidth, $checkNo);
		
	}else if ($argv[1] == "genImageWithBase64") {
		$inputFileName = $argv[2];
		$outputFileName = $argv[3];
		convertBase64ToJpegImage($inputFileName, $outputFileName);
		
	}else if ($argv[1] == "combineImages") {
		$inputFileName = $argv[2];
		$outputFileName = $argv[3];
		combineJpegImage($inputFileName, $outputFileName);
		
	}else if ($argv[1] == "convertJpegToBmp") {
		$inputFileName = $argv[2];
		$outputFileName = $argv[3];
		convertJpegToBmp($inputFileName, $outputFileName, 1);
	}
	
	/***********************************************/
	/*****			Main Functions			   *****/
	/***********************************************/
	//function txtFileToJpegImage($imgTxtFile, $billImageFile, $codepage, $chkImgWidth) {
	function txtFileToJpegImage($imgTxtFile, $billImageFile, $codepage, $checkWidth, $checkNo) {
		$lineBreakArray = array("\r\n", "\n");
		$lineIndicatorArray = array("~E", "~C", "~H", "~F", "~X", "~P", "~Y", "~U", "~V", "~B", "~S", "~r", "~b", "~K");
		$fileLineCount = 0;
		$logoHeight = 0;
		$logoWidth = 0;

		$residpi = 300/72;
		$chkImgWidth = 765;
		$ttfFontSize = 26;
		$fontSizeHeight = 38;
		if($checkWidth > 0)
			$chkImgWidth = $checkWidth;
		
	 	$checkFile = fopen($imgTxtFile, "r");
		while(!feof($checkFile)) {
			$fileLine = fgets($checkFile);
			if (strcmp(substr($fileLine, 0, 2), "~G") == 0) {
				$imageFileName = null;
				$token = strtok($fileLine, ",");
				$tokenCount = 0;
				while ($token !== false) {
					$tokenCount++;
					if($tokenCount == 2) {
						$imageFileName = trim($token);
						break;
					}
					$token = strtok(",");
				}
				
				if($imageFileName != null) {
					$imageSize =  getimagesize($imageFileName);
					$logoWidth = $imageSize[0];
					$logoHeight = $imageSize[1];
				}
			}else if (strcmp(substr($fileLine, 0, 2), "~F") == 0) {
				$feedLine = str_replace($lineIndicatorArray, "", $fileLine);
				if(is_numeric($feedLine)) {
					$fileLineCount += ($feedLine-1);
				}
			}else if (strcmp(substr($fileLine, 0, 2), "~E") == 0 || strcmp(substr($fileLine, 0, 2), "~C") == 0)
				$fileLineCount++;
			else 
				continue;
		}
		fclose($checkFile);
		$imageHeight = $fileLineCount * $fontSizeHeight;
		if ($logoHeight > 0)
			$imageHeight += $logoHeight+$fontSizeHeight;
		
		$checkImage = imagecreate($chkImgWidth,$imageHeight);
		$backgroundColor = imagecolorallocate($checkImage, 255, 255, 255);
		$textColor = imagecolorallocate($checkImage, 0, 0, 0);
		
		$checkFile = fopen($imgTxtFile, "r");
		$currentLine = 0;
		$logoPrinted = false;
		while(!feof($checkFile)) {
			$fileLine = fgets($checkFile);
			$fontSize = 2;
			
			//replace all printer used indicator
			$lineIndicator = substr($fileLine, 0, 2);
			switch ($lineIndicator) {
				case "~H":
					$fontSize = 2;
					break;
				case "~G":
					$logoImageName = null;
					$token = strtok($fileLine, ",");
					$tokenCount = 0;
					while ($token !== false) {
						$tokenCount++;
						if($tokenCount == 2) {
							$logoImageName = trim($token);
							break;
						}
						$token = strtok(",");
					}
					$logoImage = imagecreatefromjpeg($logoImageName);
					break;
				default:
					break;
			}
			
			$fileLine = str_replace($lineIndicatorArray, "", $fileLine);
			$fileLine = str_replace($lineBreakArray, "", $fileLine);
			
			$xCoordinate = 5;
			//$yCoordinate = 1+(12*$currentLine);
			$yCoordinate = 1+($fontSizeHeight*$currentLine);
			if ($logoPrinted)
				$yCoordinate += $logoHeight;
			if (strcmp($lineIndicator, "~G") == 0) {
				$logoXCoordinate = round(($chkImgWidth/2)-($logoWidth/2));
				imagecopy($checkImage, $logoImage, intval($logoXCoordinate), $yCoordinate, 0, 0, $logoWidth, $logoHeight);
				$logoPrinted = true;
			}else if (strcmp($lineIndicator, "~C") == 0) {
				if ($codepage == null || strcmp($codepage, "") == 0)
					$codepage = "ASCII";
				$fileLine = iconv($codepage, "UTF-8", $fileLine);
				imagettftext($checkImage , $ttfFontSize, 0	, $xCoordinate , $yCoordinate , $textColor , "/usr/share/fonts/xpfonts/yahei_mono.ttf" ,$fileLine);
			}else if (strcmp($lineIndicator, "~F") == 0) {
				if (is_int($fileLine)) {
					for($i=1; $i<=intval($fileLine); $fineLine)
						$yCoordinate = 1+($fontSizeHeight*$currentLine);
						imagestring($checkImage, $fontSize, $xCoordinate, $yCoordinate, $i, $textColor);
						if ($i<intval($fileLine))
							currentLine;
				}
			}else if (strcmp($lineIndicator, "~E") == 0 || strcmp($lineIndicator, "~C") == 0)
				//imagestring($checkImage, $fontSize, $xCoordinate, $yCoordinate, $fileLine, $textColor);
				imagettftext($checkImage , $ttfFontSize, 0	, $xCoordinate , $yCoordinate , $textColor , "/usr/share/fonts/xpfonts/yahei_mono.ttf" ,$fileLine);
			else
				continue;
			
			$currentLine++;
		}
		
		imagejpeg($checkImage, $billImageFile, 100);
		imagedestroy($checkImage);
	}
	
	function convertJpegImageToBase64($billImageFile, $base64OutputFile) {
		$imageData = file_get_contents($billImageFile);
		$base64 = base64_encode($imageData);
		
		$outputFile = fopen($base64OutputFile, "w");
		fputs($outputFile, $base64);
		fclose($outputFile);
	}
	
	function convertBase64ToJpegImage($inputFile, $outputFile) {
		$base64String = file_get_contents($inputFile);
		
		$jpegFile = fopen($outputFile, "w");
		fwrite($jpegFile, base64_decode($base64String));
		fclose($jpegFile);
	}
	
	function combineJpegImage($inputFileName, $outputFileName) {
		$imageFileName = array();
		$imageHeight = 0;
		$fileCount = 0;
		$chkImageWidth = 765;
		
		$fileName = strtok($inputFileName, ",");
		while($fileName != NULL) {
			$imageFileName[] = $fileName;
			$fileName = strtok(",");
		}
		
		foreach($imageFileName as $fileName) {
			$imageSize = getimagesize($fileName);
			$imageHeight += $imageSize[1];
		}
		$imageHeight += (count($imageFileName)-1)*12;
		
		$checkImage = imagecreate($chkImageWidth, $imageHeight);
		
		$yCoordinate = 0;
		foreach($imageFileName as $fileName) {
			$imageSize = getimagesize($fileName);
			$fileImage = imagecreatefromjpeg($fileName);
			imagecopy($checkImage, $fileImage, 0, $yCoordinate, 0, 0, $imageSize[0], $imageSize[1]);
			$yCoordinate += $imageSize[1]+12;
		}
		
		imagejpeg($checkImage, $outputFileName);
		imagedestroy($checkImage);
	}
	
	function convertJpegToBmp($inputFileName, $outputFileName, $bits) {
		$jpegImage = imagecreatefromjpeg($inputFileName);
		if($bits == 1)
			imageMonoBmp($jpegImage, $outputFileName);
		else
			imagebmp($jpegImage, $outputFileName);
	}
	
	/***********************************************/
	/*****			Private Functions		   *****/
	/***********************************************/
	function imagebmp(&$imageFile, $filename = false)
    {
        if (!$imageFile) return false;
        $width = imagesx($imageFile);
        $height = imagesy($imageFile);
        $result = '';

        if (!imageistruecolor($imageFile)) {
            $tmp = imagecreatetruecolor($width, $height);
            imagecopy($tmp, $imageFile, 0, 0, 0, 0, $width, $height);
            imagedestroy($imageFile);
            $imageFile = & $tmp;
        }

        $biBPLine = $width * 3;
        $biStride = ($biBPLine + 3) & ~3;
        $biSizeImage = $biStride * $height;
        $bfOffBits = 54;
        $bfSize = $bfOffBits + $biSizeImage;

        $result .= substr('BM', 0, 2);
        $result .=  pack ('VvvV', $bfSize, 0, 0, $bfOffBits);
        $result .= pack ('VVVvvVVVVVV', 40, $width, $height, 1, 24, 0, $biSizeImage, 0, 0, 0, 0);

        $numpad = $biStride - $biBPLine;
        for ($y = $height - 1; $y >= 0; --$y) {
            for ($x = 0; $x < $width; ++$x) {
                $col = imagecolorat ($imageFile, $x, $y);
                $result .=  substr(pack ('V', $col), 0, 3);
            }
            for ($i = 0; $i < $numpad; ++$i)
                $result .= pack ('C', 0);
        }

        if($filename == false){
            echo $result;
        }
        else
        {
            $file = fopen($filename, "wb");
            fwrite($file, $result);
            fclose($file);
        }
        return true;
    }
	
	function imageMonoBmp(&$image, $filename = false) {
		if(!$image)
			return false;
		
		if(!$filename)
			return false;
		
		$width = imagesx($image);
		$height = imagesy($image);
		$width_pad = str_pad('', (4-ceil($width/8) % 4) %4, "\0");

		$size = 62 + ( ceil($width/8) + strlen($width_pad)) * $height;

		//prepare & save header
		$header['identifier']       = 'BM';
		$header['file_size']        = pack("V", $size);
		$header['reserved']         = pack("V", 0);
		$header['bitmap_data']      = pack("V", 62);
		$header['header_size']      = pack("V", 40);
		$header['width']            = pack("V", $width);
		$header['height']           = pack("V", $height);
		$header['planes']           = pack("v", 1);
		$header['bits_per_pixel']   = pack("v", 1);
		$header['compression']      = pack("V", 0);
		$header['data_size']        = pack("V", 0);
		$header['h_resolution']     = pack("V", 0);
		$header['v_resolution']     = pack("V", 0);
		$header['colors']           = pack("V", 0);
		$header['important_colors'] = pack("V", 0);
		$header['white']    = chr(255).chr(255).chr(255).chr(0);
		$header['black']    = chr(0).chr(0).chr(0).chr(0);
		
		$f = fopen($filename, "wb");
		foreach ($header AS $headerContent)
			fwrite($f, $headerContent);

		//save pixels
		$str = "";
		for ($y=$height-1; $y>=0; $y--) {
			$str = "";
			for ($x=0; $x<$width; $x++) {
				$rgb = imagecolorat($image, $x, $y);
				$red = ($rgb >> 16) & 0xFF;
				$green = ($rgb >> 8) & 0xFF;
				$blue = $rgb & 0xFF;
				$gs = (($red*0.299) + ($green*0.587) + ($blue*0.114));
				if($gs>150) 
					$color=0;
				else 
					$color=1;
				$str = $str.$color;
				if($x == $width-1)
					$str=str_pad($str, 8, "0");
				if(strlen($str) == 8){
					fwrite($f, chr((int)bindec($str)));
					$str="";
				}
			}
			fwrite($f, $width_pad);
		}
		fclose($f);
	}
?>
