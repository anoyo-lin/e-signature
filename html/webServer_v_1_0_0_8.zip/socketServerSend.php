<?php	
	require ('socketServerUtility.php');
	
	if (isset($_GET['content'])) {	
		$port = (int)substr($_GET['content'], 0, 5);
		$mobileReceivedJSON = substr($_GET['content'], 5);
		
		$tmpString = str_replace('\\', "", $mobileReceivedJSON);
		$sendJsonArray = json_decode($tmpString, true);
		
		$yearMonth = date('Ym');
		$logFolderPath = "log/".$yearMonth;
		if (!is_dir($logFolderPath)) {
			$command = "mkdir ".$logFolderPath;
			exec($command);
		}
		$fileDatePrefix = date('Ymd');
		
		//open web server log file
		$logFile = fopen("log/phpSocketLog.txt",'a+');
		$result = "--------------------------------------------\n";
		fputs($logFile,$result,strlen($result));
		$result = "Receive from mobile:".$_GET['content']."\n";
		fputs($logFile, $result, strlen($result));
		
		if (strcmp($sendJsonArray["method"], "protocol_checking") == 0) {
			//check availability from mobile device				
			$response = '{"method":"'.$sendJsonArray["method"].'", "error": { "code": "0", "message": "Web server available" }, "id": "'.$sendJsonArray["id"].'" }';
			
			$result = "Receive from mobile:".$_GET['content']."\n";
			fputs($logFile, $restult, strlen($result));
			echo $response;
		}else {
			$response = '{"method":"none", "error": { "code": "-1", "message": "Invalid Request" }, "id": "'.$sendJsonArray["id"].'" }';
			
			$result = "Receive from mobile:".$_GET['content']."\n";
			fputs($logFile, $restult, strlen($result));
			echo $response;
			
		}
		
	}else if (isset($_POST['content'])) {
		//open web server log file
		$logFile = fopen("log/phpSocketLog.txt",'a+');
		$result = "--------------------------------------------\n";
		fputs($logFile,$result,strlen($result));
		$result = "Receive from mobile:".$_POST['content']."\n";
		fputs($logFile, $result, strlen($result));
		
		$yearMonth = date('Ym');
		$logFolderPath = "log/".$yearMonth;
		if (!is_dir($logFolderPath)) {
			$result = date('Y-m-d H:i:s')." Make Directory > ".$logFolderPath;
			fputs($logFile, $result, strlen($result));
			
			$command = "mkdir ".$logFolderPath;
			exec($command);
		}
		$fileDatePrefix = date('Ymd');
	
		if ($_POST['content'] == "") {
			$packetTimeout = 60;
			$nowTime = time();
			 if (($nowTime - $sendTime) > $packetTimeout) {
				$sendJsonArray = json_decode($_POST['content'], true);						
				$result = "Packet Timeout\n";
				fputs($logFile,$result,strlen($result));
				
				if (isset($sendJsonArray['params']['challenge'])) {
					$sendChallengeName = "challenge";
					$sendChallenge = $sendJsonArray['params']['challenge'];
					
				} else if (isset($sendJsonArray['params']['openchallenge'])) {
					$sendChallengeName = "openchallenge";
					$sendChallenge = $sendJsonArray['params']['openchallenge'];
				} else {
					$sendChallengeName = "challenge";
					$sendChallenge = "";
				}
				
				$response = '{ "method": "'.$sendJsonArray["method"].'", "error": { "code": "-30001", "message": "Packet Timeout", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
				echo $response;				
			 }
		}else {
			// Allow the script to hang around waiting for connections.
			$success = 0;
			$packetTimeout = 60;
			$sendTime = time();
			set_time_limit(30);

			// Turn on implicit output flushing so we see what we're getting as it comes in. 
			ob_implicit_flush();
			
			//read the POS server IP address
			$address = getServerSetting("POS_address");
			
			//get the port number and json string
			$port = (int)substr($_POST['content'], 0, 5);
			$mobileReceivedJSON = substr($_POST['content'], 5);
			
			//open web server log file
			//$portSocketLog = "log/".$yearMonth."/phpSocketLog_".$fileDatePrefix."_".$port.".txt";
			$portSocketLog = "log/".$yearMonth."/phpSocketLog_".$fileDatePrefix.".txt";
			$portSocketLogfile = fopen($portSocketLog,'a+');
			$result = "--------------------------------------------\n";
			fputs($portSocketLogfile,$result,strlen($result));
			
			$tmpString = $mobileReceivedJSON;
			$sendJsonArray = json_decode($tmpString, true);	// change the JSON string to array

			//check challenge or open challenge
			if (isset($sendJsonArray['params']['challenge'])) {
				$sendChallengeName = "challenge";
				$sendChallenge = $sendJsonArray['params']['challenge'];
				
			} else if (isset($sendJsonArray['params']['openchallenge'])) {
				$sendChallengeName = "openchallenge";
				$sendChallenge = $sendJsonArray['params']['openchallenge'];
			}else {
				$sendChallengeName = "challenge";
				$sendChallenge = "";
			}
		
				
			if ($sendJsonArray == NULL) {
				// return error if json is invalid
				$sendJsonArray = json_decode($mobileReceivedJSON, true);
				//$logMessage = date('Y-m-d H:i:s')." : Invalid JSON packet form client > ".$mobileReceivedJSON."\n";
				$logMessage = date('Y-m-d H:i:s')." ".$port." : Invalid JSON packet form client > ".$mobileReceivedJSON."]n";
				fputs($portSocketLogfile,$logMessage,strlen($logMessage));
				$response = '{ "method": "", "error": { "code": "-3001", "message": "Invalid Packet", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "" }';
				//$logMessage = date('Y-m-d H:i:s')." <<<<< ".$response."\n";
				$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response."\n";
				fputs($portSocketLogfile,$logMessage,strlen($logMessage));
				echo $response;
				
			}else {	
				// protocol checking
				if (strcmp($sendJsonArray["method"], "protocol_checking") == 0) {
					//check availability from mobile device				
					$response = '{"method":"'.$sendJsonArray["method"].'", "result": { "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
					echo $response;
				
				// get menu zip file for gmMobile
				}else if (strcmp($sendJsonArray["method"], "get_menu") == 0) {
					//$result = date('Y-m-d H:i:s')." Get menu generation info file\n";
					//fputs($portSocketLogfile,$result,strlen($result));
					
					$menuInfoFile = fopen("generation_info.txt", "r");					
					if ($menuInfoFile != NULL) {
						$infoJson = fgets($menuInfoFile);
						$result = date('Y-m-d H:i:s')." Info JSON:".$infoJson."\n";
						//fputs($portSocketLogfile,$result,strlen($result));
						//$menuInfoJsonArray = json_decode($infoJson, true);
						$response = '{"method":"'.$sendJsonArray["method"].'", "result": { "timestamp" : "'.$menuInfoJsonArray["timestamp"].'", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" } , "id": "'.$sendJsonArray["id"].'" }';
						echo $response;
						
					}else {
						$response = '{"method":"'.$sendJsonArray["method"].'", "error": { "code": "-3001", "message": "Fail to get generation info file", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
						echo $response;
					}
					
					fclose($menuInfoFile);
				
				}else {
					//send json request to POS side
					//create the socket to POS
					if (($sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) === false) {
						//$result = date('Y-m-d H:i:s')." socket_create() failed > reason: " . socket_strerror(socket_last_error()) . "\n";
						$result = date('Y-m-d H:i:s')." ".$port." socket_create() failed > reason: ".socket_strerror(socket_last_error())."\n";
						fputs($portSocketLogfile,$result,strlen($result));
						$tmpString = str_replace('\\', "", $mobileReceivedJSON);
						$sendJsonArray = json_decode($tmpString, true);
						$response = '{"method":"'.$sendJsonArray["method"].'", "error": { "code": "-30001", "message": "Fail to connect POS server", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
						
						//$logMessage = date('Y-m-d H:i:s')." <<<<< ".$response."\n";
						$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response."\n";
						fputs($portSocketLogfile,$logMessage,strlen($logMessage));
						
						echo $response;
						
					}else {
						//connect socket
						if ($result = socket_connect($sock, $address, $port) === false) {				
							//$result = date('Y-m-d H:i:s')." socket_connect() failed > reason: " . socket_strerror(socket_last_error($sock)) . "\n";
							$result = date('Y-m-d H:i:s')." ".$port." socket_connect() failed > reason: ".socket_strerror(socket_last_error($sock))."\n";
							fputs($portSocketLogfile,$result,strlen($result));
							//fputs($portSocketLogfile, (date('Y-m-d H:i:s')."POS-server:".$address.",Port Number:".$port."\n"));
							fputs($portSocketLogfile, (date('Y-m-d H:i:s')." ".$port." POS-server:".$address.",Port Number:".$port."\n"));
							$tmpString = str_replace('\\', "", $mobileReceivedJSON);
							$sendJsonArray = json_decode($tmpString, true);			
							$response = '{"method":"'.$sendJsonArray["method"].'","error":{"code":"-30001", "message":"Fail to connect POS server", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'"}, "id": "'.$sendJsonArray["id"].'" }';
							
							//$logMessage = date('Y-m-d H:i:s')." <<<<< ".$response."\n";
							$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response."\n";
							fputs($portSocketLogfile,$logMessage,strlen($logMessage));
							
							echo $response;
							
						}else {	
							// connection build successfully			
							$result = date('Y-m-d H:i:s')." ".$port." Connect to POS (address-$address, port-$port):\n";
							fputs($portSocketLogfile,$result,strlen($result));
								
							$talkback = chr(0x01).$mobileReceivedJSON.chr(0x04); // add start and end index
							if ($result = socket_write($sock, $talkback, strlen($talkback)) === false) {
								// fail to write socket to POS server
								$result = date('Y-m-d H:i:s')." ".$port." Fail to send packet\n";
								fputs($portSocketLogfile,$result,strlen($result));
								
							}else {
								$result = date('Y-m-d H:i:s')." ".$port." >>>>> ".$talkback."\n";
								fputs($portSocketLogfile,$result,strlen($result));
								
								// read the response from pos
								$success = 0;
								$finalReply = "";
								do {
									$recv = "";
									socket_set_option($sock, SOL_SOCKET, SO_RCVTIMEO, array('sec' => 30,'usec' => 0));
									$recv = socket_read($sock, '10000');
									$recvStrLength = strlen($recv);
									if($recv != "") {
										if ($recv[($recvStrLength-1)] == chr(0x04)) {
											$finalReply = $finalReply.$recv;
											$success = 1;
											break;
										}else 
											$finalReply = $finalReply.$recv;
									}
									 
								} while($recv != "");
								
								// check packet timeout
								$nowTime = time();
								if (($nowTime - $sendTime) > $packetTimeout) {
									$sendJsonArray = json_decode($mobileReceivedJSON, true);						
									$result = date('Y-m-d H:i:s')." ".$port." Packet Timeout\n";
									fputs($portSocketLogfile, $result, strlen($result));
									$response = '{ "method": "'.$sendJsonArray["method"].'", "error": { "code": "-30001", "message": "Packet Timeout", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
									
									//$logMessage = date('Y-m-d H:i:s')." <<<<< ".$response."\n";
									$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response."\n";
									fputs($portSocketLogfile, $logMessage, strlen($logMessage));
									
									echo $response;
									break;
								}
								
								// handle return from POS					
								if ($success == 1) {
									$len = strlen($finalReply);
									$jsonString = substr($finalReply, 1, ($len-2));
									
									$recvJsonArray = json_decode($jsonString, true);
									
									if ($recvJsonArray == NULL) {
										// invalid JSON response from POS server
										$sendJsonArray = json_decode($mobileReceivedJSON, true);						
										$result = date('Y-m-d H:i:s')." ".$port." (form server) Invalid Packet > ".$jsonString."\n";
										fputs($portSocketLogfile,$result,strlen($result));
										$response = '{ "method": "'.$sendJsonArray["method"].'", "error": { "code": "-30001", "message": "Invalid Packet", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
										
										//$logMessage = date('Y-m-d H:i:s')." <<<<< ".$response."\n";
										$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response."\n";
										fputs($portSocketLogfile,$logMessage,strlen($logMessage));
										
										//$result = "Response from Web Server to Client:".$response."\n";
										//fputs($portSocketLogfile,$result,strlen($result));
										
										echo $response;
										
									}else if ($recvJsonArray["result"] >= 0) {
										// success result from POS server and handle the result according to request method
										// if request method is "check_menu"
										if (strcmp($recvJsonArray["method"], "check_menu") == 0) {
											//$result = "get menu generation info file\n";
											$result = date('Y-m-d H:i:s')." ".$port." Check menu generation info file\n";
											fputs($portSocketLogfile,$result,strlen($result));
											
											$menuInfoFile = fopen("generation_info.txt", "r");					
											if ($menuInfoFile != NULL) {
												$infoJson = fgets($menuInfoFile);
												//$result = "Info JSON:".$infoJson."\n";
												//fputs($portSocketLogfile,$result,strlen($result));
												$menuInfoJsonArray = json_decode($infoJson, true);												
												
												if ($recvJsonArray["result"] != NULL) {
													$time = $recvJsonArray["result"]["time"];
													$challenge = $recvJsonArray["result"]["challenge"];
												}else {
													$time = $recvJsonArray["error"]["time"];
													$challenge = $recvJsonArray["error"]["challenge"];
												}
												
												$response = '{"method":"'.$sendJsonArray["method"].'", "result": { "timestamp" : "'.$menuInfoJsonArray["timestamp"].'" , "time":"'.$time.'", "challenge":"'.$challenge.'"} , "id": "'.$sendJsonArray["id"].'" }';
												
												/*$result = "Response from Web Server to Client:".$response."\n";
												fputs($portSocketLogfile,$result,strlen($result));*/
												
												$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response."\n";
												fputs($portSocketLogfile,$logMessage,strlen($logMessage));
												
												echo $response;
												
											}else {
												$response = '{"method":"'.$sendJsonArray["method"].'", "error": { "code": "-30001", "message": "Fail to get generation info file", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
												
												$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response."\n";
												fputs($portSocketLogfile,$logMessage,strlen($logMessage));
												
												echo $response;
											}
											
											fclose($menuInfoFilei);
											
										// if request method is "get_product_key"
										}else if (strcmp($recvJsonArray["method"], "get_product_key") == 0) {
											$response = getProductKey($portSocketLogfile, $sendJsonArray, $recvJsonArray);
											
											$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response."\n";
											fputs($portSocketLogfile,$logMessage,strlen($logMessage));
											
											echo $response;
										
										// others request method
										}else {
											$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$jsonString."\n";
											fputs($portSocketLogfile,$logMessage,strlen($logMessage));
											
											echo $jsonString;
										}
									}else {										
										// error response from POS server
										$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$jsonString."\n";
										fputs($portSocketLogfile,$logMessage,strlen($logMessage));
										
										echo $jsonString;
									}
								
								}else {
									//Packet timeout for waiting the response from POS server
									$sendJsonArray = json_decode($mobileReceivedJSON, true);						
									$result = date('Y-m-d H:i:s')." ".$port." (waiting response from server) Packet Timeout\n";
									fputs($portSocketLogfile,$result,strlen($result));
									
									$response = '{ "method": "'.$sendJsonArray["method"].'", "error": { "code": "-30001", "message": "Packet Timeout", "time":"'.$sendJsonArray['params']['time'].'", "'.$sendChallengeName.'":"'.$sendChallenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
									
									$logMessage = date('Y-m-d H:i:s')." ".$port." <<<<< ".$response;
									fputs($portSocketLogfile,$logMessage,strlen($logMessage));
									
									echo $response;
									
								}
							}
						}
					}
					socket_close($sock);
				}
			}
			fclose($portSocketLogfile);
		}
		fclose($logFile);
	}else 
		echo "No Data";
		
/**********************************************************************/
/*             			Supported Function							  */
/**********************************************************************/
function getProductKey($portLogFile, $sendJsonArray, $recvJsonArray) {
	if ($recvJsonArray["result"] != NULL) {
		$time = $recvJsonArray["result"]["time"];
		$challenge = $recvJsonArray["result"]["challenge"];
	}else {
		$time = $recvJsonArray["error"]["time"];
		$challenge = $recvJsonArray["error"]["challenge"];
	}
	
	$deviceKeyFile = fopen("data/deviceKey.txt", "r");					
	if ($deviceKeyFile != NULL) {
		$iUUIDFound = 0;
		
		 while (($string = fgets($deviceKeyFile)) !== false) {
			$tmpUUID = "";
			$tmpKey = "";
			$tmpExpiryDate = "";
			
			$tmp = strtok($string, ",");
			$tmpUUID = $tmp;
			$tmp = strtok(",");
			$tmpKey = $tmp;
			$tmp = strtok("\n");
			$tmpExpiryDate = $tmp;
			
			if (strcmp($tmpUUID, $sendJsonArray["params"]["uuid"]) == 0) {
				$iUUIDFound = 1;
				$key = $tmpKey;
				$expiryDate = $tmpExpiryDate;
				break;
			}
		
		}
		fclose($deviceKeyFile);	
		
		if ($iUUIDFound)
			$response = '{"method":"'.$sendJsonArray["method"].'", "result": { "key" : "'.$key.'" , "expdate":"'.$expiryDate.'", "time":"'.$time.'", "challenge":"'.$challenge.'"} , "id": "'.$sendJsonArray["id"].'" }';
		else	
			$response = '{"method":"'.$sendJsonArray["method"].'", "result": { "key" : "" , "time":"'.$time.'", "challenge":"'.$challenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
		
	}else {
			
		$response = '{"method":"'.$sendJsonArray["method"].'", "error": { "code": "-3001", "message": "Fail to get deviceKey file", "time":"'.$time.'", "challenge":"'.$challenge.'" }, "id": "'.$sendJsonArray["id"].'" }';
		
	}
	
	return $response;
}

?>
