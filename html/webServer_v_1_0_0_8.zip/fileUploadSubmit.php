<?php
	echo ("<h2>Upload File</h2>");
	echo ("Please choose the file to be processed:");
	echo ("<form action='fileUpload.php' method='POST' enctype='multipart/form-data'>");			
	echo ("<b>File to be upload </b><input type='file' name='file' id='file'>");
	echo ("<br><input type='submit' value='Process'>");			
	echo ("</form>");
?>
