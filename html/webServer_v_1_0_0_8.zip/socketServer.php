<?php 
	//uitility program for PHP socket
?>
	<html>
	<head>
		<title>PHP socket</title>
		<meta http-equiv="Content-Type" content="text/html; charset=BIG5">
	</head>

	<body>
		<div>
			<form id='openSocket' name='getData' action='socketServerSend.php' method='POST'>
			Text1: <input type='text' name='content' size=450>
			<!-- <BR>Text2: <input type='text' name='content2'> -->
			<br><input type='submit' id='submit' name='submit' value='Submit'>
			</form>
		</div>
	</body>
	</html>
