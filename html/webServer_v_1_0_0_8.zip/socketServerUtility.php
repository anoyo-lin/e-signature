<?php
	function getServerSetting($settingName) {
		$settingValue = "";
		
		$serverSettingFile = fopen("data/config.inf", "r");
		if ($serverSettingFile != NULL) {
			while (!feof($serverSettingFile)) {
				$buffer = fgets($serverSettingFile);
				$tok = strtok($buffer, "=");
				$receSettingName = trim($tok, " ");
				
				if ($tok !== false && strcmp($receSettingName, $settingName) == 0) {					
					$tok = strtok("=");
					$settingValue = trim($tok, " \n");
				}
			}
		}
		
		return $settingValue;
	}
?>
