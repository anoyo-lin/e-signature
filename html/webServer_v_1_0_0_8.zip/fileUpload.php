<?php
	if ($_FILES['file']['error'] > 0)
	{
		echo "Error:".$_FILES['file']['error'];
	}else {
		//setting the target path to save the uploaded file
		//$sTargetPath = "/var/www/html/testing/uploads/";
		$sTargetPath = "./uploads/";
		$sTargetPath = $sTargetPath . basename( $_FILES['file']['name']); 
		$sFileExtension = substr($_FILES['file']['name'], (stripos($_FILES['file']['name'], ".")+1), 3);
		
		if (strcmp($sFileExtension, "jpg") != 0) {
			echo ("-32140");
			$iUploadError = 1;
		}else if(move_uploaded_file($_FILES['file']['tmp_name'], $sTargetPath) && $iUploadError == 0) {
			//upload the file from client to server
			echo "0";
		}else if ($iUploadError == 0) {
			echo "-32141";
			$iUploadError = 1;
		}
	}
?>
